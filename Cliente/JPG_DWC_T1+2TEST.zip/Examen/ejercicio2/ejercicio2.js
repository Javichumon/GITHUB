function setBackgroundColor(color) {

    document.body.style.backgroundColor = color;

}

